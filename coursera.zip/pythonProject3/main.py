import cv2
import pybluez

# Bluetooth device information
target_name = "Your Mobile Device Name"
target_address = None

# Search for the target Bluetooth device
devices = pybluez.discover_devices()
for device_address in devices:
    device_name = pybluez.lookup_name(device_address)
    if target_name == device_name:
        target_address = device_address
        break

if target_address is not None:
    print(f"Found target device: {target_name} ({target_address})")
else:
    print("Target device not found.")
    exit()

# Establish Bluetooth connection with the target device
socket = pybluez.BluetoothSocket(pybluez.RFCOMM)
port = 1  # RFCOMM port number
socket.connect((target_address, port))
print("Bluetooth connection established.")

# Receive video stream from the mobile device's camera
capture = cv2.VideoCapture(socket)

while True:
    ret, frame = capture.read()
    if ret:
        # Display the video stream
        cv2.imshow("Camera", frame)
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

# Release resources
capture.release()
socket.close()
cv2.destroyAllWindows()
