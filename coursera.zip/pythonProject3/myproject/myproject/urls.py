from django.urls import path
from myapp.views import login_view

urlpatterns = [
    # Other URL patterns
    path('login/', login_view, name='login'),
]
